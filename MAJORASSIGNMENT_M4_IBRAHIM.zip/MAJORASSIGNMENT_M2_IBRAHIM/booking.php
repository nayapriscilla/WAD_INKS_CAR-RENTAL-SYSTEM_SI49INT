<?php

$conn = mysqli_connect("localhost", "root", "", "rental_package");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM booking";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <title>Booking Data</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: whitesmoke;
            margin: 0;
            padding: 40px;
        }

        h1 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            margin-top: 30px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: black;
            color: white;
        }

        a {
            color: black;
        }

        .action {
            white-space: nowrap;
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 25px;
        }

    </style>

</head>

<body>

    <h1>Booking Data</h1>

    <table>

        <tr>
            <th>ID</th>
            <th>Package</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Rental Date</th>
            <th>Duration</th>
            <th>Pick-up Location</th>
            <th>Special Request</th>
            <th>Action</th>
        </tr>


        <?php while ($row = mysqli_fetch_assoc($result)) { ?>

            <tr>

                <td><?php echo $row["id"]; ?></td>

                <td><?php echo $row["package"]; ?></td>

                <td><?php echo $row["name"]; ?></td>

                <td><?php echo $row["phone"]; ?></td>

                <td><?php echo $row["rental_date"]; ?></td>

                <td>
                    <?php echo $row["duration"];  ?>
                </td>

                <td>
                    <?php echo $row["pickup_location"]; ?>
                </td>

                <td>
                    <?php echo $row["special_request"]; ?>
                </td>

                <td class="action">

                    <a href="edit.php?id=<?php echo $row["id"]; ?>">
                        Edit
                    </a>

                    |

                    <a href="delete.php?id=<?php echo $row["id"]; ?>">
                        Delete
                    </a>

                </td>

            </tr>

        <?php } ?>

    </table>

    <a href="index.php" class="back">
        ← Back to Packages
    </a>

</body>

</html>