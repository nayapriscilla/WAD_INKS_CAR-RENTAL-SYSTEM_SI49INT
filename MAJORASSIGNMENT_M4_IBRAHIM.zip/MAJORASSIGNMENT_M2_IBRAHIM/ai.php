<?php

$packageName = "All-In";
$description = "Enjoy your trip with a professional driver included";

$name = "";
$phone = "";
$date = "";
$duration = "";
$location = "";
$request = "";
$message = "";


$conn = mysqli_connect("localhost", "root", "", "rental_package");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST["name"];
    $phone = $_POST["phone"];
    $date = $_POST["date"];
    $duration = $_POST["duration"];
    $location = $_POST["location"];
    $request = $_POST["request"];


    // Insert data into booking table
    $sql = "INSERT INTO booking
            (package, name, phone, rental_date, duration, pickup_location, special_request)
            VALUES
            ('$packageName', '$name', '$phone', '$date', '$duration', '$location', '$request')";


    if (mysqli_query($conn, $sql)) {

        $message = "Your booking has been successfully saved!";

    } else {

        $message = "Error: " . mysqli_error($conn);

    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>All-In Package</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: whitesmoke;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 500px;
            margin: 40px auto;
        }

        .package-info {
            text-align: center;
            margin-bottom: 30px;
        }

        .package-info h1 {
            margin-bottom: 10px;
        }

        .package-info p {
            color: #666;
        }

        .form-box {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
        }

        .form-box h2 {
            text-align: center;
            margin-top: 0;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        textarea {
            height: 80px;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;

            background-color: black;
            color: white;

            border: none;
            border-radius: 4px;

            cursor: pointer;
        }

        button:hover {
            background-color: #333;
        }

        .message {
            background-color: #e8f5e9;
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 4px;
            text-align: center;
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: black;
            text-decoration: none;
        }

        .back:hover {
            text-decoration: underline;
        }

    </style>

</head>


<body>

    <div class="container">

        <div class="package-info">

            <h1>
                <?php echo $packageName; ?>
            </h1>

            <p>
                <?php echo $description; ?>
            </p>

        </div>


        <div class="form-box">

            <h2>Book This Package</h2>


            <?php

            if ($message != "") {
                echo "<div class='message'>$message</div>";
            }

            ?>


            <form method="POST" action="">

                <label>Full Name</label>

                <input
                    type="text"
                    name="name"
                    value="<?php echo $name; ?>"
                    required
                >


                <label>Phone Number</label>

                <input
                    type="text"
                    name="phone"
                    value="<?php echo $phone; ?>"
                    required
                >


                <label>Rental Date</label>

                <input
                    type="date"
                    name="date"
                    value="<?php echo $date; ?>"
                    required
                >


                <label>Duration</label>

                <select name="duration" required>

                    <option value="">
                        Choose Duration
                    </option>

                    <option value="1"
                        <?php
                        if ($duration == "1") {
                            echo "selected";
                        }
                        ?>
                    >
                        1 Day
                    </option>

                    <option value="2"
                        <?php
                        if ($duration == "2") {
                            echo "selected";
                        }
                        ?>
                    >
                        2 Days
                    </option>

                    <option value="3"
                        <?php
                        if ($duration == "3") {
                            echo "selected";
                        }
                        ?>
                    >
                        3 Days
                    </option>

                    <option value="4"
                        <?php
                        if ($duration == "4") {
                            echo "selected";
                        }
                        ?>
                    >
                        4 Days
                    </option>

                    <option value="5"
                        <?php
                        if ($duration == "5") {
                            echo "selected";
                        }
                        ?>
                    >
                        5 Days
                    </option>

                </select>


                <label>Pick-up Location</label>

                <input
                    type="text"
                    name="location"
                    value="<?php echo $location; ?>"
                    required
                >


                <label>Special Request</label>

                <textarea
                    name="request"
                ><?php echo $request; ?></textarea>


                <button type="submit">
                    Book Package
                </button>

            </form>


            <a href="index.php" class="back">
                ← Back to Packages
            </a>

            <a href="booking.php" class="back">
                View Booking Data
            </a>

        </div>

    </div>

</body>

</html>