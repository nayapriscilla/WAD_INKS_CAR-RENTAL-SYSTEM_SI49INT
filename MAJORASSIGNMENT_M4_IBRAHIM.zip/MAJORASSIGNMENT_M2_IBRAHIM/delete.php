<?php

$conn = mysqli_connect("localhost", "root", "", "rental_package");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$id = $_GET["id"];


$sql = "DELETE FROM booking WHERE id = $id";


if (mysqli_query($conn, $sql)) {

    header("Location: booking.php");
    exit();

} else {

    echo "Delete failed: " . mysqli_error($conn);

}

?>