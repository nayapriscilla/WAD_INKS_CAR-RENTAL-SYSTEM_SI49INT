<?php
$title = "Rental Packages";
$subtitle = "Choose the rental package that suits your trip.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: whitesmoke;
            padding: 40px;
        }

        h1 {
            text-align: center;
            color: black;
        }

        .subtitle {
            text-align: center;
            color: rgb(103, 102, 102);
            margin-bottom: 40px;
        }

        .packages {
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        .package {
            background-color: white;
            width: 280px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        .package h2 {
            color: #1d5fa7;
        }

        .package h3 {
            margin-bottom: 5px;
        }

        .package p {
            color: #555;
        }

        .package ul {
            padding-left: 20px;
        }

        .package li {
            margin-bottom: 8px;
        }

        .button {
            display: inline-block;
            background-color: #1d5fa7;
            color: white;
            padding: 10px 18px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            margin-top: 10px;
        }

        .button:hover {
            background-color: #164b85;
        }
    </style>
</head>
<body>

    <h1><?php echo $title; ?></h1>
    <p class="subtitle"><?php echo $subtitle; ?></p>

    <div class="packages">
        <div class="package">
            <h2>Self-Drive</h2>
            <p>Drive the car yourself and enjoy your trip freely.</p>

            <h3>Duration</h3>
            <p>1 - 7 Days</p>

            <h3>Conditions</h3>
            <ul>
                <li>Valid driving license (SIM A)</li>
                <li>Minimum age 21 years old</li>
                <li>Valid ID card required</li>
            </ul>

            <a href="sd.php" class="button">Choose Package</a>
        </div>

        <div class="package">
            <h2>All-In</h2>
            <p>Enjoy your trip with a professional driver included.</p>

            <h3>Duration</h3>
            <p>1 - 7 Days</p>

            <h3>Conditions</h3>
            <ul>
                <li>Professional driver included</li>
                <li>Suitable for city trips</li>
                <li>Extra charge for additional hours</li>
            </ul>

            <a href="ai.php" class="button">Choose Package</a>
        </div>

        <div class="package">
            <h2>Out of Town</h2>
            <p>Rental package for trips outside the city.</p>

            <h3>Duration</h3>
            <p>2 - 7 Days</p>

            <h3>Conditions</h3>
            <ul>
                <li>Professional driver included</li>
                <li>Available for out of town trips</li>
                <li>Additional charges may apply</li>
            </ul>

            <a href="oot.php" class="button">Choose Package</a>
        </div>
    </div>

</body>
</html>
