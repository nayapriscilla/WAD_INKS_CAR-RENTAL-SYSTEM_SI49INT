<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Gate;
use Illuminate\View\View;

class BookingController extends Controller
{
    public function index(Request $request): View
    {
        Gate::authorize('viewAny', Booking::class);

        $user = $request->user();

        $bookings = Booking::query()
            ->when($user->role !== 'admin', function ($query) use ($user) {
                $query->where('user_id', $user->id);
            })
            ->orderBy('id', 'desc')
            ->get();

        return view('booking.index', compact('bookings'));
    }

    public function create(): View
    {
        Gate::authorize('create', Booking::class);

        return view('booking.create');
    }

    public function store(Request $request): RedirectResponse
    {
        Gate::authorize('create', Booking::class);

        $validated = $request->validate([
            'package' => 'required|string|max:50',
            'name' => 'required|string|max:100',
            'phone' => 'required|string|max:20',
            'rental_date' => 'required|date',
            'duration' => 'required|integer|min:1',
            'pickup_location' => 'required|string|max:150',
            'special_request' => 'nullable|string',
        ]);

        $validated['user_id'] = $request->user()->id;

        Booking::create($validated);

        return redirect()->route('bookings.index')
            ->with('success', 'Booking berhasil ditambahkan!');
    }

    public function edit(Booking $booking): View
    {
        Gate::authorize('update', $booking);

        return view('booking.edit', compact('booking'));
    }

    public function update(Request $request, Booking $booking): RedirectResponse
    {
        Gate::authorize('update', $booking);

        $validated = $request->validate([
            'package' => 'required|string|max:50',
            'name' => 'required|string|max:100',
            'phone' => 'required|string|max:20',
            'rental_date' => 'required|date',
            'duration' => 'required|integer|min:1',
            'pickup_location' => 'required|string|max:150',
            'special_request' => 'nullable|string',
        ]);

        $booking->update($validated);

        return redirect()->route('bookings.index')
            ->with('success', 'Booking berhasil diperbarui!');
    }

    public function destroy(Booking $booking): RedirectResponse
    {
        Gate::authorize('delete', $booking);

        $booking->delete();

        return redirect()->route('bookings.index')
            ->with('success', 'Booking berhasil dihapus!');
    }
}
