<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $table = 'booking';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'package',
        'name',
        'phone',
        'rental_date',
        'duration',
        'pickup_location',
        'special_request',
    ];

    protected $casts = [
        'rental_date' => 'date',
        'duration' => 'integer',
    ];

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

}
