<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Booking</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            padding: 30px;
        }
        form {
            max-width: 550px;
            background: white;
            padding: 25px;
            border-radius: 8px;
        }
        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }
        input, select, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
        }
        button {
            background: #2563eb;
            color: white;
            padding: 12px 20px;
            border: none;
            margin-top: 20px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Create New Booking</h1>

    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <form action="<?php echo e(route('bookings.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Package</label>
        <select name="package" required>
            <option value="Self-Drive">Self-Drive</option>
            <option value="All-In">All-In</option>
            <option value="Out of Town">Out of Town</option>
        </select>

        <label>Customer Name</label>
        <input type="text" name="name" value="<?php echo e(old('name')); ?>" required>

        <label>Phone Number</label>
        <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" required>

        <label>Rental Date</label>
        <input type="date" name="rental_date" value="<?php echo e(old('rental_date')); ?>" required>

        <label>Duration (Days)</label>
        <input type="number" name="duration" min="1" value="<?php echo e(old('duration')); ?>" required>

        <label>Pickup Location</label>
        <input type="text" name="pickup_location" value="<?php echo e(old('pickup_location')); ?>" required>

        <label>Special Request</label>
        <textarea name="special_request"><?php echo e(old('special_request')); ?></textarea>

        <button type="submit">Save Booking</button>
    </form>

    <p><a href="<?php echo e(route('bookings.index')); ?>">Back to Booking List</a></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\muhammad_farrel_ibrahim\WAD-INKS-IBRAHIM-102022500258\MAJORASSIGNMENT_M2_IBRAHIM\rental-package-laravel\resources\views/booking/create.blade.php ENDPATH**/ ?>