<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental Package - Booking List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            padding: 30px;
        }
        h1 { color: #222; }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #2563eb;
            color: white;
        }
    </style>
</head>
<body>
    <h1>Rental Package - Booking List</h1>
    <?php if(auth()->guard()->check()): ?>
        <p>Welcome, <?php echo e(Auth::user()->name); ?>!</p>

        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit"
                style="background:#dc2626;color:white;border:none;padding:10px 20px;cursor:pointer;margin-bottom:20px;">
                Logout
            </button>
        </form>
    <?php endif; ?>
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Booking::class)): ?>
        <p>
            <a href="<?php echo e(route('bookings.create')); ?>"
            style="display:inline-block;background:#2563eb;color:white;padding:12px 20px;text-decoration:none;margin-bottom:15px;">
                + Create New Booking
            </a>
        </p>
    <?php endif; ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Package</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Rental Date</th>
                <th>Duration</th>
                <th>Pickup Location</th>
                <th>Special Request</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($booking->id); ?></td>
                    <td><?php echo e($booking->package); ?></td>
                    <td><?php echo e($booking->name); ?></td>
                    <td><?php echo e($booking->phone); ?></td>
                    <td><?php echo e($booking->rental_date->format('Y-m-d')); ?></td>
                    <td><?php echo e($booking->duration); ?></td>
                    <td><?php echo e($booking->pickup_location); ?></td>
                    <td><?php echo e($booking->special_request ?? '-'); ?></td>
                    
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $booking)): ?>
                            <a href="<?php echo e(route('bookings.edit', $booking->id)); ?>">
                                Edit
                            </a>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $booking)): ?>
                            <form action="<?php echo e(route('bookings.destroy', $booking->id)); ?>"
                                method="POST"
                                style="display:inline;"
                                onsubmit="return confirm('Are you sure you want to delete this booking?');">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit"
                                    style="background:#dc2626;color:white;border:none;padding:8px 12px;cursor:pointer;margin-left:10px;">
                                    Delete
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9">No booking data found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\muhammad_farrel_ibrahim\WAD-INKS-IBRAHIM-102022500258\MAJORASSIGNMENT_M2_IBRAHIM\rental-package-laravel\resources\views/booking/index.blade.php ENDPATH**/ ?>