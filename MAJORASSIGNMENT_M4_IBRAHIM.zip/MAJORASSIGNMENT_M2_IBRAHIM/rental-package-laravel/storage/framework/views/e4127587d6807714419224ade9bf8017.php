<div <?php echo e($attributes->merge(['class' => "h-0 w-full relative"])); ?>>
    <div class="absolute top-[-1px] left-0 right-0 bottom-0 border-t border-dashed border-neutral-300 dark:border-white/[9%]"></div>
</div>
<?php /**PATH C:\xampp\htdocs\muhammad_farrel_ibrahim\WAD-INKS-IBRAHIM-102022500258\MAJORASSIGNMENT_M2_IBRAHIM\rental-package-laravel\vendor\laravel\framework\src\Illuminate\Foundation\resources\exceptions\renderer/components/separator.blade.php ENDPATH**/ ?>