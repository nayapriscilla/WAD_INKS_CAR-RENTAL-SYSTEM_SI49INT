<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental Package - Booking List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            padding: 30px;
        }
        h1 { color: #222; }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #2563eb;
            color: white;
        }
    </style>
</head>
<body>
    <h1>Rental Package - Booking List</h1>
    @auth
        <p>Welcome, {{ Auth::user()->name }}!</p>

        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button type="submit"
                style="background:#dc2626;color:white;border:none;padding:10px 20px;cursor:pointer;margin-bottom:20px;">
                Logout
            </button>
        </form>
    @endauth
    
    @can('create', App\Models\Booking::class)
        <p>
            <a href="{{ route('bookings.create') }}"
            style="display:inline-block;background:#2563eb;color:white;padding:12px 20px;text-decoration:none;margin-bottom:15px;">
                + Create New Booking
            </a>
        </p>
    @endcan
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Package</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Rental Date</th>
                <th>Duration</th>
                <th>Pickup Location</th>
                <th>Special Request</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($bookings as $booking)
                <tr>
                    <td>{{ $booking->id }}</td>
                    <td>{{ $booking->package }}</td>
                    <td>{{ $booking->name }}</td>
                    <td>{{ $booking->phone }}</td>
                    <td>{{ $booking->rental_date->format('Y-m-d') }}</td>
                    <td>{{ $booking->duration }}</td>
                    <td>{{ $booking->pickup_location }}</td>
                    <td>{{ $booking->special_request ?? '-' }}</td>
                    
                    <td>
                        @can('update', $booking)
                            <a href="{{ route('bookings.edit', $booking->id) }}">
                                Edit
                            </a>
                        @endcan

                        @can('delete', $booking)
                            <form action="{{ route('bookings.destroy', $booking->id) }}"
                                method="POST"
                                style="display:inline;"
                                onsubmit="return confirm('Are you sure you want to delete this booking?');">

                                @csrf
                                @method('DELETE')

                                <button type="submit"
                                    style="background:#dc2626;color:white;border:none;padding:8px 12px;cursor:pointer;margin-left:10px;">
                                    Delete
                                </button>
                            </form>
                        @endcan
                    </td>

                </tr>
            @empty
                <tr>
                    <td colspan="9">No booking data found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
</body>
</html>
