<?php

$conn = mysqli_connect("localhost", "root", "", "rental_package");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


// Get booking ID
$id = $_GET["id"];


// Get old booking data
$sql = "SELECT * FROM booking WHERE id = $id";
$result = mysqli_query($conn, $sql);

$data = mysqli_fetch_assoc($result);


// Update booking
if (isset($_POST["update"])) {

    $name = $_POST["name"];
    $phone = $_POST["phone"];
    $date = $_POST["date"];
    $duration = $_POST["duration"];
    $location = $_POST["location"];
    $request = $_POST["request"];


    $sql = "UPDATE booking SET
            name = '$name',
            phone = '$phone',
            rental_date = '$date',
            duration = '$duration',
            pickup_location = '$location',
            special_request = '$request'
            WHERE id = $id";


    if (mysqli_query($conn, $sql)) {

        header("Location: booking.php");
        exit();

    } else {

        echo "Update failed: " . mysqli_error($conn);

    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <title>Edit Booking</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: whitesmoke;
        }

        .form-box {
            width: 500px;
            background-color: white;
            margin: 40px auto;
            padding: 30px;
            border-radius: 8px;
        }

        h1 {
            text-align: center;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
        }

        textarea {
            height: 80px;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background-color: black;
            color: white;
            border: none;
            cursor: pointer;
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: black;
        }

    </style>

</head>


<body>

<div class="form-box">

    <h1>Edit Booking</h1>

    <form method="POST">

        <label>Full Name</label>

        <input
            type="text"
            name="name"
            value="<?php echo $data["name"]; ?>"
            required
        >


        <label>Phone Number</label>

        <input
            type="text"
            name="phone"
            value="<?php echo $data["phone"]; ?>"
            required
        >


        <label>Rental Date</label>

        <input
            type="date"
            name="date"
            value="<?php echo $data["rental_date"]; ?>"
            required
        >


        <label>Duration</label>

        <select name="duration">

            <option value="1"
                <?php if ($data["duration"] == 1) echo "selected"; ?>>
                1 Day
            </option>

            <option value="2"
                <?php if ($data["duration"] == 2) echo "selected"; ?>>
                2 Days
            </option>

            <option value="3"
                <?php if ($data["duration"] == 3) echo "selected"; ?>>
                3 Days
            </option>

            <option value="4"
                <?php if ($data["duration"] == 4) echo "selected"; ?>>
                4 Days
            </option>

            <option value="5"
                <?php if ($data["duration"] == 5) echo "selected"; ?>>
                5 Days
            </option>

        </select>


        <label>Pick-up Location</label>

        <input
            type="text"
            name="location"
            value="<?php echo $data["pickup_location"]; ?>"
            required
        >


        <label>Special Request</label>

        <textarea name="request"><?php
            echo $data["special_request"];
        ?></textarea>


        <button
            type="submit"
            name="update">
            Update Booking
        </button>

    </form>


    <a href="booking.php" class="back">
        ← Back to Booking Data
    </a>

</div>

</body>

</html>