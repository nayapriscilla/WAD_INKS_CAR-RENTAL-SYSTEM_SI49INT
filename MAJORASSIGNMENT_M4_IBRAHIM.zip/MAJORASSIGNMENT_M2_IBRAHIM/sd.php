<?php
$packageName = "Self-Drive";
$description = "Drive the car yourself and enjoy your trip freely";
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $duration = $_POST["duration"];
    $message = "Thank you, " . $name . ". You chose Self-Drive for " . $duration . " day(s).";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $packageName; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: whitesmoke;
            padding: 40px;
        }

        h1 {
            text-align: center;
            color: black;
        }

        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 40px;
        }

        .form {
            display: flex;
            justify-content: center;
        }

        .forma {
            background-color: white;
            width: 500px;
            padding: 25px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        .pf {
            text-align: center;
            color: black;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
        }

        button, .back {
            display: inline-block;
            background-color: #1d5fa7;
            color: white;
            padding: 10px 18px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            margin-top: 20px;
            cursor: pointer;
        }

        .message {
            background-color: #eeeeee;
            padding: 12px;
            margin-top: 20px;
            border-radius: 6px;
        }
    </style>
</head>
<body>

    <h1><?php echo $packageName; ?></h1>
    <p class="subtitle"><?php echo $description; ?></p>

    <div class="form">
        <div class="forma">
            <p class="pf">Please fulfill the form below to continue</p>

            <form method="POST" action="">
                <label>Name</label>
                <input type="text" name="name" placeholder="Enter your name" required>

                <label>Rental Duration</label>
                <select name="duration" required>
                    <option value="">Choose duration</option>
                    <option value="1">1 Day</option>
                    <option value="2">2 Days</option>
                    <option value="3">3 Days</option>
                    <option value="4">4 Days</option>
                    <option value="5">5 Days</option>
                    <option value="6">6 Days</option>
                    <option value="7">7 Days</option>
                </select>

                <button type="submit">Submit</button>
                <a href="index.php" class="back">Back</a>
            </form>

            <?php if ($message != "") { ?>
                <p class="message"><?php echo $message; ?></p>
            <?php } ?>
        </div>
    </div>

</body>
</html>
